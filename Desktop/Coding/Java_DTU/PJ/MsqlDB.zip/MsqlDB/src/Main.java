import java.sql.*;



class Main {
    public static void Bed_avail(String dept){
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Hospital_JAVA", "root", "sql");
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("select Pati_Dept from Patient");
            int counter_bed = 0;
            //if (rs.absolute(1)) //start counting from 1 or replace by the col name
            while (rs.next()){
                if (rs.getString(1).equals(dept))
                //the number inside the get function refers to the original position of the table construction, not query
                    counter_bed ++;
            }

            rs = stmt.executeQuery("select * from Facility");
            while (rs.next()){
                if (rs.getString(1).equals(dept)){
                    System.out.println("Total bed available for '" + dept + "' department is " + (rs.getInt(2) - counter_bed));
                    break;}
            }
            
            con.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public static void main(String args[]) {
        // "emergency", "inpatient", "outpatient"
        Bed_avail("emergency");
        Bed_avail("inpatient");
        Bed_avail("outpatient");
    }
}
